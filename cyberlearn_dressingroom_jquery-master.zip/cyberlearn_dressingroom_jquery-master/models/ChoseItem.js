function ChoseItem(id, type, name, desc, imgsrc_jpg, imgsrc_png) {
  this.id = id;
  this.type = type;
  this.name = name;
  this.desc = desc;
  this.imgsrc_jpg = imgsrc_jpg;
  this.imgsrc_png = imgsrc_png;
}

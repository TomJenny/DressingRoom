function ListChosen() {
  this.arr = [];

  this.addAddItem = function(item) {
    this.arr.push(item);
  };
}

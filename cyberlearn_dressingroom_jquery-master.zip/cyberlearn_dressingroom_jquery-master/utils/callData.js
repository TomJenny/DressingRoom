function CallData() {
  this.getListData = function() {
    return $.getJSON("./../data/Data.json");
  };
}
